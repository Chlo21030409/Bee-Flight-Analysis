Flight mill R script

rm(list=ls())

#### SET WD #####
setwd("/Users/chloe/Documents/IMPERIAL (MSc)/MSc EEC/Project/Data/Flight mill raw data/csv files/")
dir()

##### LOAD DATA #####
d <-read.csv("04062019.csv", header = T)

flight_date <- d[1,1]

##### LOAD PACKAGES ######
require(dplyr)
require(magicfor)
require(xts)

#### TIDY DATA #####
# rename columns
colnames(d) <-  c("Mill", "Circuit", "Interval")

# remove unwanted rows 
d <- d[-c(1:17), ]

# put in mill order 
d <- arrange(d, desc(Mill))

#### SUBSET INTO MILLS #####
mill1<- subset(d, d$Mill == 1)
rownames(mill1) <- NULL 
mill2 <- subset(d, d$Mill == 2)
rownames(mill2) <- NULL 
mill3 <- subset(d, d$Mill == 3)
rownames(mill3) <- NULL 
mill4 <- subset(d, d$Mill == 4)
rownames(mill4) <- NULL 
mill5 <- subset(d, d$Mill == 5)
rownames(mill5) <- NULL 
mill6 <- subset(d, d$Mill == 6)
rownames(mill6) <- NULL 

# change factors to numeric 
mill1$Interval <- as.character(mill1$Interval)
mill1$Interval <- as.numeric(mill1$Interval)
mill1$Circuit <- as.character(mill1$Circuit)
mill1$Circuit<- as.numeric(mill1$Circuit)

mill2$Interval <- as.character(mill2$Interval)
mill2$Interval <- as.numeric(mill2$Interval)
mill2$Circuit <- as.character(mill2$Circuit)
mill2$Circuit<- as.numeric(mill2$Circuit)

mill3$Interval <- as.character(mill3$Interval)
mill3$Interval <- as.numeric(mill3$Interval)
mill3$Circuit <- as.character(mill3$Circuit)
mill3$Circuit<- as.numeric(mill3$Circuit)

mill4$Interval <- as.character(mill4$Interval)
mill4$Interval <- as.numeric(mill4$Interval)
mill4$Circuit <- as.character(mill4$Circuit)
mill4$Circuit<- as.numeric(mill4$Circuit)

mill5$Interval <- as.character(mill5$Interval)
mill5$Interval <- as.numeric(mill5$Interval)
mill5$Circuit <- as.character(mill5$Circuit)
mill5$Circuit<- as.numeric(mill5$Circuit)

mill6$Interval <- as.character(mill6$Interval)
mill6$Interval <- as.numeric(mill6$Interval)
mill6$Circuit <- as.character(mill6$Circuit)
mill6$Circuit<- as.numeric(mill6$Circuit)

# Remove first 5 rows mills
mill1 <- mill1[-(1:6), ]
mill2 <- mill2[-(1:6), ]
mill3 <- mill3[-(1:6), ]
mill4 <- mill4[-(1:6), ]
mill5 <- mill5[-(1:6), ]
mill6 <- mill6[-(1:6), ]

# add cumulative column for interval 
mill1 <- mutate(mill1, cum_interval = cumsum(Interval))
mill2 <- mutate(mill2, cum_interval = cumsum(Interval))
mill3 <- mutate(mill3, cum_interval = cumsum(Interval))
mill4 <- mutate(mill4, cum_interval = cumsum(Interval))
mill5 <- mutate(mill5, cum_interval = cumsum(Interval))
mill6 <- mutate(mill6, cum_interval = cumsum(Interval))

# make interval = "cutoff" if total time is > 7,200 secs (2 hours)
mill1$cum_interval[mill1$cum_interval >7200] <- "cutoff"
mill2$cum_interval[mill2$cum_interval >7200] <- "cutoff"
mill3$cum_interval[mill3$cum_interval >7200] <- "cutoff"
mill4$cum_interval[mill4$cum_interval >7200] <- "cutoff"
mill5$cum_interval[mill5$cum_interval >7200] <- "cutoff"
mill6$cum_interval[mill6$cum_interval >7200] <- "cutoff"

# remove "cutoff" circuits from data (before data cleaning)
mill1 <- filter(mill1, mill1$cum_interval != "cutoff")
mill2 <- filter(mill2, mill2$cum_interval != "cutoff")
mill3 <- filter(mill3, mill3$cum_interval != "cutoff")
mill4 <- filter(mill4, mill4$cum_interval != "cutoff")
mill5 <- filter(mill5, mill5$cum_interval != "cutoff")
mill6 <- filter(mill6, mill6$cum_interval != "cutoff")


####### REMOVE INTERVALS GREATER THAN 20secs & 5 INTERVALS EACH SIDE OF STOP #########
###### Can adjust time as suited #######

# Make intervals >20s = "STOP

mill1$Interval[mill1$Interval >= 20.0] <- "STOP"
mill2$Interval[mill2$Interval >= 20.0] <- "STOP"
mill3$Interval[mill3$Interval >= 20.0] <- "STOP"
mill4$Interval[mill4$Interval >= 20.0] <- "STOP"
mill5$Interval[mill5$Interval >= 20.0] <- "STOP"
mill6$Interval[mill6$Interval >= 20.0] <- "STOP"


# make circuits with intervals >20s = "STOP"
mill1$Circuit[mill1$Interval == "STOP"] <- "STOP"
mill2$Circuit[mill2$Interval == "STOP"] <- "STOP"
mill3$Circuit[mill3$Interval == "STOP"] <- "STOP"
mill4$Circuit[mill4$Interval == "STOP"] <- "STOP"
mill5$Circuit[mill5$Interval == "STOP"] <- "STOP"
mill6$Circuit[mill6$Interval == "STOP"] <- "STOP"


# determine the row numbers for the STOPS and +/- 5 surrounding rows

#### MILL 1 #####
# identify which rows contain a stop 
row_n <- which(mill1$Interval == "STOP", arr.ind=TRUE)

# determine the number of stops
stop_num <- length(row_n)

# determine if bee flew up to 2 hour cut off time 
mill1$Interval <- as.numeric(mill1$Interval)
time <- sum(mill1$Interval)

# get upper row numbers for stops 
# if there are no stops in the data upper and lower row numbers will default to 0 and only the last 5 rows will be deleted. 

if(stop_num > 0) {
  magic_for(print, silent = T)
  for(i in row_n) { 
    a <- i + 5
    a
    x <- print(a)} 
  upper <- magic_result_as_dataframe()
  upper<- upper[ ,2]} else {
    upper <- 0}

# get lower value row numbers of the stops
if(stop_num > 0) {
  for(i in row_n) { 
    b <- i - 5
    b
    y <- print(b)}
  lower <- magic_result_as_dataframe()
  lower <- lower[ ,2]} else {
    lower <- 0}

# add last row value for mill 1
end <- nrow(mill1)
end <- rep(end, times = stop_num)

# find the last 5 rows to remove from data if bee stops less than 3 times 
lastrow <- nrow(mill1)
end5 <- (lastrow - 5)


# bind cols togetheer
bound <- cbind(lower, upper, end)
bound <- data.frame(bound)
# ensure that row is always positive number
bound$lower[bound$lower < 0] <- 0 

# ensure that upper bound is not greater than number of rows 
bound$upper[bound$upper > lastrow] <- lastrow

#  making the 5 rows either side of a stop = "stop" for only 1/2 stop/s will also make the last 5 rows of data = "stops"
# for 3 or more stops will make all intervals = "stop" after the third stop 
if(stop_num <= 1) {
  stop1_l <- bound[1,1 ] 
  stop1_u <- bound[1,2]
  mill1$Interval[stop1_l:stop1_u] <- "stop"
  mill1$Interval[end5:lastrow] <- "stop"} else 
  {if(stop_num == 2) {
    stop1_l <- bound[1,1] 
    stop1_u <- bound[1,2] 
    stop2_l <- bound[2,1]
    stop2_u <- bound[2,2]
    mill1$Interval[stop1_l:stop1_u] <- "stop"
    mill1$Interval[stop2_l:stop2_u] <- "stop"
    mill1$Interval[end5:lastrow] <- "stop"} else {
      if(stop_num >= 3) {
        stop1_l <- bound[1,1] 
        stop1_u <- bound[1,2] 
        stop2_l <- bound[2,1]
        stop2_u <- bound[2,2]
        stop3_l <- bound[3,1]
        finish <- bound[3,3]
        mill1$Interval[stop1_l:stop1_u] <- "stop"
        mill1$Interval[stop2_l:stop2_u] <- "stop"
        mill1$Interval[stop3_l:finish] <- "stop"
      }}}

# Add column to identify the the circuits before each stop
mill1 <- mutate(mill1, Leg = mill1$Interval)

if(stop_num < 1) {
  mill1$Leg[1:lastrow] <- "leg 1" } else {
    if(stop_num == 1) {
      mill1$Leg[1:stop1_l] <- "leg 1" 
      mill1$Leg[stop1_u:lastrow] <- "leg 2"} else {
        if(stop_num == 2) {
          mill1$Leg[1:stop1_l] <- "leg 1"
          mill1$Leg[stop1_u:stop2_l] <- "leg 2"
          mill1$Leg[stop2_u:lastrow] <- "leg 3" } else {
            if(stop_num >= 3) {
              mill1$Leg[1:stop1_l] <- "leg 1"
              mill1$Leg[stop1_u:stop2_l] <- "leg 2" 
              mill1$Leg[stop2_u:stop3_l] <- "leg 3"
            }}}}

# remove the "stops" from data 
clean_d_mill1 <- filter(mill1, mill1$Interval != "stop")
clean_d_mill1 <- filter(clean_d_mill1, mill1$Interval != "NA")

# make intervals values numeric 
clean_d_mill1$Interval <- as.numeric(clean_d_mill1$Interval)


####### MILL 2 #######
# identify which rows contain a stop 
row_n <- which(mill2$Interval == "STOP", arr.ind=TRUE)

# determine the number of stops
stop_num <- length(row_n)

# get upper row numbers for stops
if(stop_num > 0) {
  magic_for(print, silent = T)
  for(i in row_n) { 
    a <- i + 5
    a
    x <- print(a)} 
  upper <- magic_result_as_dataframe()
  upper<- upper[ ,2]} else {
    upper <- 0}

# get lower value row numbers of the stops
if(stop_num > 0) {
  for(i in row_n) { 
    b <- i - 5
    b
    y <- print(b)}
  lower <- magic_result_as_dataframe()
  lower <- lower[ ,2]} else {
    lower <- 0}

# add last row value for mill 1
end <- nrow(mill2)
end <- rep(end, times = stop_num)

# find the last 5 rows to remove from data if bee stops less than 3 times 
lastrow <- nrow(mill2)
end5 <- (lastrow - 5)


# bind cols togetheer
bound <- cbind(lower, upper, end)
bound <- data.frame(bound)
# ensure row is always a positive number
bound$lower[bound$lower < 0] <- 0 

# ensure that upper bound is not greater than number of rows 
bound$upper[bound$upper > lastrow] <- lastrow

#  making the 5 rows either side of a stop = "stop" for only 1/2 stop/s will also make the last 5 rows of data = "stops"
# for 3 or more stops will make all intervals = "stop" after the third stop 
if(stop_num <= 1) {
  stop1_l <- bound[1,1 ] 
  stop1_u <- bound[1,2]
  mill2$Interval[stop1_l:stop1_u] <- "stop"
  mill2$Interval[end5:lastrow] <- "stop"} else 
  {if(stop_num == 2) {
    stop1_l <- bound[1,1] 
    stop1_u <- bound[1,2] 
    stop2_l <- bound[2,1]
    stop2_u <- bound[2,2]
    mill2$Interval[stop1_l:stop1_u] <- "stop"
    mill2$Interval[stop2_l:stop2_u] <- "stop"
    mill2$Interval[end5:lastrow] <- "stop"} else {
      if(stop_num >= 3) {
        stop1_l <- bound[1,1] 
        stop1_u <- bound[1,2] 
        stop2_l <- bound[2,1]
        stop2_u <- bound[2,2]
        stop3_l <- bound[3,1]
        finish <- bound[3,3]
        mill2$Interval[stop1_l:stop1_u] <- "stop"
        mill2$Interval[stop2_l:stop2_u] <- "stop"
        mill2$Interval[stop3_l:finish] <- "stop"
      }}}


# Add column to identify the the circuits before each stop
mill2 <- mutate(mill2, Leg = mill2$Interval)

if(stop_num < 1) {
  mill2$Leg[1:lastrow] <- "leg 1" } else {
    if(stop_num == 1) {
      mill2$Leg[1:stop1_l] <- "leg 1" 
      mill2$Leg[stop1_u:lastrow] <- "leg 2"} else {
        if(stop_num == 2) {
          mill2$Leg[1:stop1_l] <- "leg 1"
          mill2$Leg[stop1_u:stop2_l] <- "leg 2"
          mill2$Leg[stop2_u:lastrow] <- "leg 3" } else {
            if(stop_num >= 3) {
              mill2$Leg[1:stop1_l] <- "leg 1"
              mill2$Leg[stop1_u:stop2_l] <- "leg 2" 
              mill2$Leg[stop2_u:stop3_l] <- "leg 3"
            }}}}



# remove the "stops" from data 
clean_d_mill2 <- filter(mill2, mill2$Interval != "stop")
clean_d_mill2 <- filter(clean_d_mill2, mill2$Interval != "NA")

# make intervals values numeric 
clean_d_mill2$Interval <- as.numeric(clean_d_mill2$Interval)


####### MILL 3 #######
row_n <- which(mill3$Interval == "STOP", arr.ind=TRUE)

# determine the number of stops
stop_num <- length(row_n)

# get upper row numbers for stops
if(stop_num > 0) {
  magic_for(print, silent = T)
  for(i in row_n) { 
    a <- i + 5
    a
    x <- print(a)} 
  upper <- magic_result_as_dataframe()
  upper<- upper[ ,2]} else {
    upper <- 0}

# get lower value row numbers of the stops
if(stop_num > 0) {
  for(i in row_n) { 
    b <- i - 5
    b
    y <- print(b)}
  lower <- magic_result_as_dataframe()
  lower <- lower[ ,2]} else {
    lower <- 0}

# add last row value for mill 1
end <- nrow(mill3)
end <- rep(end, times = stop_num)

# find the last 5 rows to remove from data if bee stops less than 3 times 
lastrow <- nrow(mill3)
end5 <- (lastrow - 5)


# bind cols togetheer
bound <- cbind(lower, upper, end)
bound <- data.frame(bound)
# ensure row is always a positive number
bound$lower[bound$lower < 0] <- 0 

# ensure that upper bound is not greater than number of rows 
bound$upper[bound$upper > lastrow] <- lastrow

#  making the 5 rows either side of a stop = "stop" for only 1/2 stop/s will also make the last 5 rows of data = "stops"
# for 3 or more stops will make all intervals = "stop" after the third stop 
if(stop_num <= 1) {
  stop1_l <- bound[1,1 ] 
  stop1_u <- bound[1,2]
  mill3$Interval[stop1_l:stop1_u] <- "stop"
  mill3$Interval[end5:lastrow] <- "stop"} else 
  {if(stop_num == 2) {
    stop1_l <- bound[1,1] 
    stop1_u <- bound[1,2] 
    stop2_l <- bound[2,1]
    stop2_u <- bound[2,2]
    mill3$Interval[stop1_l:stop1_u] <- "stop"
    mill3$Interval[stop2_l:stop2_u] <- "stop"
    mill3$Interval[end5:lastrow] <- "stop"} else {
      if(stop_num >= 3) {
        stop1_l <- bound[1,1] 
        stop1_u <- bound[1,2] 
        stop2_l <- bound[2,1]
        stop2_u <- bound[2,2]
        stop3_l <- bound[3,1]
        finish <- bound[3,3]
        mill3$Interval[stop1_l:stop1_u] <- "stop"
        mill3$Interval[stop2_l:stop2_u] <- "stop"
        mill3$Interval[stop3_l:finish] <- "stop"
      }}}

# Add column to identify the the circuits before each stop
mill3 <- mutate(mill3, Leg = mill3$Interval)

if(stop_num < 1) {
  mill3$Leg[1:lastrow] <- "leg 1" } else {
    if(stop_num == 1) {
      mill3$Leg[1:stop1_l] <- "leg 1" 
      mill3$Leg[stop1_u:lastrow] <- "leg 2"} else {
        if(stop_num == 2) {
          mill3$Leg[1:stop1_l] <- "leg 1"
          mill3$Leg[stop1_u:stop2_l] <- "leg 2"
          mill3$Leg[stop2_u:lastrow] <- "leg 3" } else {
            if(stop_num >= 3) {
              mill3$Leg[1:stop1_l] <- "leg 1"
              mill3$Leg[stop1_u:stop2_l] <- "leg 2" 
              mill3$Leg[stop2_u:stop3_l] <- "leg 3"
            }}}}


# remove the "stops" from data 
clean_d_mill3 <- filter(mill3, mill3$Interval != "stop")
clean_d_mill3 <- filter(clean_d_mill3, mill3$Interval != "NA")

# make intervals values numeric 
clean_d_mill3$Interval <- as.numeric(clean_d_mill3$Interval)



####### MILL 4 ########
row_n <- which(mill4$Interval == "STOP", arr.ind=TRUE)

# determine the number of stops
stop_num <- length(row_n)

# get upper row numbers for stops
if(stop_num > 0) {
  magic_for(print, silent = T)
  for(i in row_n) { 
    a <- i + 5
    a
    x <- print(a)} 
  upper <- magic_result_as_dataframe()
  upper<- upper[ ,2]} else {
    upper <- 0}

# get lower value row numbers of the stops
if(stop_num > 0) {
  for(i in row_n) { 
    b <- i - 5
    b
    y <- print(b)}
  lower <- magic_result_as_dataframe()
  lower <- lower[ ,2]} else {
    lower <- 0}

# add last row value for mill 1
end <- nrow(mill4)
end <- rep(end, times = stop_num)

# find the last 5 rows to remove from data if bee stops less than 3 times 
lastrow <- nrow(mill4)
end5 <- (lastrow - 5)


# bind cols togetheer
bound <- cbind(lower, upper, end)
bound <- data.frame(bound)
# ensure row is always a positive number
bound$lower[bound$lower < 0] <- 0 

# ensure that upper bound is not greater than number of rows 
bound$upper[bound$upper > lastrow] <- lastrow

#  making the 5 rows either side of a stop = "stop" for only 1/2 stop/s will also make the last 5 rows of data = "stops"
# for 3 or more stops will make all intervals = "stop" after the third stop 
if(stop_num <= 1) {
  stop1_l <- bound[1,1 ] 
  stop1_u <- bound[1,2]
  mill4$Interval[stop1_l:stop1_u] <- "stop"
  mill4$Interval[end5:lastrow] <- "stop"} else 
  {if(stop_num == 2) {
    stop1_l <- bound[1,1] 
    stop1_u <- bound[1,2] 
    stop2_l <- bound[2,1]
    stop2_u <- bound[2,2]
    mill4$Interval[stop1_l:stop1_u] <- "stop"
    mill4$Interval[stop2_l:stop2_u] <- "stop"
    mill4$Interval[end5:lastrow] <- "stop"} else {
      if(stop_num >= 3) {
        stop1_l <- bound[1,1] 
        stop1_u <- bound[1,2] 
        stop2_l <- bound[2,1]
        stop2_u <- bound[2,2]
        stop3_l <- bound[3,1]
        finish <- bound[3,3]
        mill4$Interval[stop1_l:stop1_u] <- "stop"
        mill4$Interval[stop2_l:stop2_u] <- "stop"
        mill4$Interval[stop3_l:finish] <- "stop"
      }}}


# Add column to identify the the circuits before each stop
mill4 <- mutate(mill4, Leg = mill4$Interval)

if(stop_num < 1) {
  mill4$Leg[1:lastrow] <- "leg 1" } else {
    if(stop_num == 1) {
      mill4$Leg[1:stop1_l] <- "leg 1" 
      mill4$Leg[stop1_u:lastrow] <- "leg 2"} else {
        if(stop_num == 2) {
          mill4$Leg[1:stop1_l] <- "leg 1"
          mill4$Leg[stop1_u:stop2_l] <- "leg 2"
          mill4$Leg[stop2_u:lastrow] <- "leg 3" } else {
            if(stop_num >= 3) {
              mill4$Leg[1:stop1_l] <- "leg 1"
              mill4$Leg[stop1_u:stop2_l] <- "leg 2" 
              mill4$Leg[stop2_u:stop3_l] <- "leg 3"
            }}}}


# remove the "stops" from data 
clean_d_mill4 <- filter(mill4, mill4$Interval != "stop")
clean_d_mill4 <- filter(clean_d_mill4, mill4$Interval != "NA")

# make intervals values numeric 
clean_d_mill4$Interval <- as.numeric(clean_d_mill4$Interval)



####### MILL 5 ########
row_n <- which(mill5$Interval == "STOP", arr.ind=TRUE)

# determine the number of stops
stop_num <- length(row_n)

# get upper row numbers for stops
if(stop_num > 0) {
  magic_for(print, silent = T)
  for(i in row_n) { 
    a <- i + 5
    a
    x <- print(a)} 
  upper <- magic_result_as_dataframe()
  upper<- upper[ ,2]} else {
    upper <- 0}

# get lower value row numbers of the stops
if(stop_num > 0) {
  for(i in row_n) { 
    b <- i - 5
    b
    y <- print(b)}
  lower <- magic_result_as_dataframe()
  lower <- lower[ ,2]} else {
    lower <- 0}

# add last row value for mill 1
end <- nrow(mill5)
end <- rep(end, times = stop_num)

# find the last 5 rows to remove from data if bee stops less than 3 times 
lastrow <- nrow(mill5)
end5 <- (lastrow - 5)


# bind cols togetheer
bound <- cbind(lower, upper, end)
bound <- data.frame(bound)
# ensure row is always a positive number
bound$lower[bound$lower < 0] <- 0 

# ensure that upper bound is not greater than number of rows 
bound$upper[bound$upper > lastrow] <- lastrow

#  making the 5 rows either side of a stop = "stop" for only 1/2 stop/s will also make the last 5 rows of data = "stops"
# for 3 or more stops will make all intervals = "stop" after the third stop 
if(stop_num <= 1) {
  stop1_l <- bound[1,1 ] 
  stop1_u <- bound[1,2]
  mill5$Interval[stop1_l:stop1_u] <- "stop"
  mill5$Interval[end5:lastrow] <- "stop"} else 
  {if(stop_num == 2) {
    stop1_l <- bound[1,1] 
    stop1_u <- bound[1,2] 
    stop2_l <- bound[2,1]
    stop2_u <- bound[2,2]
    mill5$Interval[stop1_l:stop1_u] <- "stop"
    mill5$Interval[stop2_l:stop2_u] <- "stop"
    mill5$Interval[end5:lastrow] <- "stop"} else {
      if(stop_num >= 3) {
        stop1_l <- bound[1,1] 
        stop1_u <- bound[1,2] 
        stop2_l <- bound[2,1]
        stop2_u <- bound[2,2]
        stop3_l <- bound[3,1]
        finish <- bound[3,3]
        mill5$Interval[stop1_l:stop1_u] <- "stop"
        mill5$Interval[stop2_l:stop2_u] <- "stop"
        mill5$Interval[stop3_l:finish] <- "stop"
      }}}

# Add column to identify the the circuits before each stop
mill5 <- mutate(mill5, Leg = mill5$Interval)

if(stop_num < 1) {
  mill5$Leg[1:lastrow] <- "leg 1" } else {
    if(stop_num == 1) {
      mill5$Leg[1:stop1_l] <- "leg 1" 
      mill5$Leg[stop1_u:lastrow] <- "leg 2"} else {
        if(stop_num == 2) {
          mill5$Leg[1:stop1_l] <- "leg 1"
          mill5$Leg[stop1_u:stop2_l] <- "leg 2"
          mill5$Leg[stop2_u:lastrow] <- "leg 3" } else {
            if(stop_num >= 3) {
              mill5$Leg[1:stop1_l] <- "leg 1"
              mill5$Leg[stop1_u:stop2_l] <- "leg 2" 
              mill5$Leg[stop2_u:stop3_l] <- "leg 3"
            }}}}


# remove the "stops" from data 
clean_d_mill5 <- filter(mill5, mill5$Interval != "stop")
clean_d_mill5 <- filter(clean_d_mill5, mill5$Interval != "NA")

# make intervals values numeric 
clean_d_mill5$Interval <- as.numeric(clean_d_mill5$Interval)



####### MILL 6 ########

row_n <- which(mill6$Interval == "STOP", arr.ind=TRUE)

# determine the number of stops
stop_num <- length(row_n)

# get upper row numbers for stops
if(stop_num > 0) {
  magic_for(print, silent = T)
  for(i in row_n) { 
    a <- i + 5
    a
    x <- print(a)} 
  upper <- magic_result_as_dataframe()
  upper<- upper[ ,2]} else {
    upper <- 0}

# get lower value row numbers of the stops
if(stop_num > 0) {
  for(i in row_n) { 
    b <- i - 5
    b
    y <- print(b)}
  lower <- magic_result_as_dataframe()
  lower <- lower[ ,2]} else {
    lower <- 0}

# add last row value for mill 1
end <- nrow(mill6)
end <- rep(end, times = stop_num)

# find the last 5 rows to remove from data if bee stops less than 3 times 
lastrow <- nrow(mill6)
end5 <- (lastrow - 5)


# bind cols togetheer
bound <- cbind(lower, upper, end)
bound <- data.frame(bound)
# ensure row is always a positive number
bound$lower[bound$lower < 0] <- 0 

# ensure that upper bound is not greater than number of rows 
bound$upper[bound$upper > lastrow] <- lastrow

#  making the 5 rows either side of a stop = "stop" for only 1/2 stop/s will also make the last 5 rows of data = "stops"
# for 3 or more stops will make all intervals = "stop" after the third stop 
if(stop_num <= 1) {
  stop1_l <- bound[1,1 ] 
  stop1_u <- bound[1,2]
  mill6$Interval[stop1_l:stop1_u] <- "stop"
  mill6$Interval[end5:lastrow] <- "stop"} else 
  {if(stop_num == 2) {
    stop1_l <- bound[1,1] 
    stop1_u <- bound[1,2] 
    stop2_l <- bound[2,1]
    stop2_u <- bound[2,2]
    mill6$Interval[stop1_l:stop1_u] <- "stop"
    mill6$Interval[stop2_l:stop2_u] <- "stop"
    mill6$Interval[end5:lastrow] <- "stop"} else {
      if(stop_num >= 3) {
        stop1_l <- bound[1,1] 
        stop1_u <- bound[1,2] 
        stop2_l <- bound[2,1]
        stop2_u <- bound[2,2]
        stop3_l <- bound[3,1]
        finish <- bound[3,3]
        mill6$Interval[stop1_l:stop1_u] <- "stop"
        mill6$Interval[stop2_l:stop2_u] <- "stop"
        mill6$Interval[stop3_l:finish] <- "stop"
      }}}

# Add column to identify the the circuits before each stop
mill6 <- mutate(mill6, Leg = mill6$Interval)

if(stop_num < 1) {
  mill6$Leg[1:lastrow] <- "leg 1" } else {
    if(stop_num == 1) {
      mill6$Leg[1:stop1_l] <- "leg 1" 
      mill6$Leg[stop1_u:lastrow] <- "leg 2"} else {
        if(stop_num == 2) {
          mill6$Leg[1:stop1_l] <- "leg 1"
          mill6$Leg[stop1_u:stop2_l] <- "leg 2"
          mill6$Leg[stop2_u:lastrow] <- "leg 3" } else {
            if(stop_num >= 3) {
              mill6$Leg[1:stop1_l] <- "leg 1"
              mill6$Leg[stop1_u:stop2_l] <- "leg 2" 
              mill6$Leg[stop2_u:stop3_l] <- "leg 3"
            }}}}


# remove the "stops" from data 
clean_d_mill6 <- filter(mill6, mill6$Interval != "stop")
clean_d_mill6 <- filter(clean_d_mill6, mill6$Interval != "NA")

# make intervals values numeric 
clean_d_mill6$Interval <- as.numeric(clean_d_mill6$Interval)

############ CALCULATE DISTANCE, NUMBER OF CIRCUITS & DURATION FOR MILLS ###############

##### MILL 1 ########                   
Distance <- c(rep(0.848, times = nrow(clean_d_mill1)))
clean_d_mill1 <- cbind(clean_d_mill1, Distance)
clean_d_mill1$speed <- (0.848/clean_d_mill1$Interval)

#### calculate total circuits and distance flown (metres) ####
# circuits
m1_total_circuits <- nrow(clean_d_mill1)
m1_total_circuits
# distance (m)
m1_total_dist <- nrow(clean_d_mill1)*0.848
m1_total_dist

# calculate average speed
# total distance flown 
total_dist <- sum(clean_d_mill1$Distance)
# total time flown 
total_time <- sum(clean_d_mill1$Interval)
# average speed 
mean_speed1<- total_dist/total_time

# calculate distance for each leg 
leg1_m1 <- filter(clean_d_mill1, clean_d_mill1$Leg == "leg 1")
leg1_distm1 <- sum(leg1_m1$Distance)

leg2_m1 <- filter(clean_d_mill1, clean_d_mill1$Leg == "leg 2")
leg2_distm1 <- sum(leg2_m1$Distance)

leg3_m1 <- filter(clean_d_mill1, clean_d_mill1$Leg == "leg 3")
leg3_distm1 <- sum(leg3_m1$Distance)

# calculate total duration of flight 
flight_time_m1 <-sum(clean_d_mill1$Interval)

# calculate duration of each leg 
flighttime_m1leg1 <- sum(leg1_m1$Interval)
flighttime_m1leg2 <- sum(leg2_m1$Interval)
flighttime_m1leg3 <- sum(leg3_m1$Interval)


##### MILL 2 #######
Distance <- c(rep(0.848, times = nrow(clean_d_mill2)))
clean_d_mill2 <- cbind(clean_d_mill2, Distance)
clean_d_mill2$speed <- (0.848/clean_d_mill2$Interval)

#### calculate total circuits and distance flown (metres) ####
# circuits
m2_total_circuits <- nrow(clean_d_mill2)
m2_total_circuits
# distance (m)
m2_total_dist <- nrow(clean_d_mill2)*0.848
m2_total_dist

# calculate average speed
# total distance flown 
total_dist <- sum(clean_d_mill2$Distance)
# total time flown 
total_time <- sum(clean_d_mill2$Interval)
# average speed 
mean_speed2 <- total_dist/total_time

# calculate distance for each leg 
leg1_m2 <- filter(clean_d_mill2, clean_d_mill2$Leg == "leg 1")
leg1_distm2 <- sum(leg1_m2$Distance)

leg2_m2 <- filter(clean_d_mill2, clean_d_mill2$Leg == "leg 2")
leg2_distm2 <- sum(leg2_m2$Distance)

leg3_m2 <- filter(clean_d_mill2, clean_d_mill2$Leg == "leg 3")
leg3_distm2 <- sum(leg3_m2$Distance)

# calculate total duration of flight 
flight_time_m2 <-sum(clean_d_mill2$Interval)

# calculate duration of each leg 
flighttime_m2leg1 <- sum(leg1_m2$Interval)
flighttime_m2leg2 <- sum(leg2_m2$Interval)
flighttime_m2leg3 <- sum(leg3_m2$Interval)

##### MILL 3 ######
Distance <- c(rep(0.848, times = nrow(clean_d_mill3)))
clean_d_mill3 <- cbind(clean_d_mill3, Distance)
clean_d_mill3$speed <- (0.848/clean_d_mill3$Interval)

#### calculate total circuits and distance flown (metres) ####
# circuits
m3_total_circuits <- nrow(clean_d_mill3)
m3_total_circuits
# distance (m)
m3_total_dist <- nrow(clean_d_mill3)*0.848
m3_total_dist

# calculating average speed
# total distance flown 
total_dist <- sum(clean_d_mill3$Distance)
# total time flown 
total_time <- sum(clean_d_mill3$Interval)
# average speed 
mean_speed3 <- total_dist/total_time

# calculating distance for each leg 
leg1_m3 <- filter(clean_d_mill3, clean_d_mill3$Leg == "leg 1")
leg1_distm3 <- sum(leg1_m3$Distance)

leg2_m3 <- filter(clean_d_mill3, clean_d_mill3$Leg == "leg 2")
leg2_distm3 <- sum(leg2_m3$Distance)

leg3_m3 <- filter(clean_d_mill3, clean_d_mill3$Leg == "leg 3")
leg3_distm3 <- sum(leg3_m3$Distance)

# calculate total duration of flight 
flight_time_m3 <-sum(clean_d_mill3$Interval)

# calculate duration of each leg 
flighttime_m3leg1 <- sum(leg1_m3$Interval)
flighttime_m3leg2 <- sum(leg2_m3$Interval)
flighttime_m3leg3 <- sum(leg3_m3$Interval)

##### MILL 4 ######

Distance <- c(rep(0.848, times = nrow(clean_d_mill4)))
clean_d_mill4 <- cbind(clean_d_mill4, Distance)
clean_d_mill4$speed <- (0.848/clean_d_mill4$Interval)

#### calculate total circuits and distance flown (metres) ####
# circuits
m4_total_circuits <- nrow(clean_d_mill4)
m4_total_circuits
# distance (m)
m4_total_dist <- nrow(clean_d_mill4)*0.848
m4_total_dist

# calculating average speed
# total distance flown 
total_dist <- sum(clean_d_mill4$Distance)
# total time flown 
total_time <- sum(clean_d_mill4$Interval)
# average speed 
mean_speed4 <- total_dist/total_time

# calculating distance for each leg 
leg1_m4 <- filter(clean_d_mill4, clean_d_mill4$Leg == "leg 1")
leg1_distm4 <- sum(leg1_m4$Distance)

leg2_m4 <- filter(clean_d_mill4, clean_d_mill4$Leg == "leg 2")
leg2_distm4 <- sum(leg2_m4$Distance)

leg3_m4 <- filter(clean_d_mill4, clean_d_mill4$Leg == "leg 3")
leg3_distm4 <- sum(leg3_m4$Distance)

# calculate total duration of flight 
flight_time_m4 <-sum(clean_d_mill4$Interval)

# calculate duration of each leg 
flighttime_m4leg1 <- sum(leg1_m4$Interval)
flighttime_m4leg2 <- sum(leg2_m4$Interval)
flighttime_m4leg3 <- sum(leg3_m4$Interval)

##### MILL 5 ######

Distance <- c(rep(0.848, times = nrow(clean_d_mill5)))
clean_d_mill5 <- cbind(clean_d_mill5, Distance)
clean_d_mill5$speed <- (0.848/clean_d_mill5$Interval)

#### calculate total circuits and distance flown (metres) ####
# circuits
m5_total_circuits <- nrow(clean_d_mill5)
m5_total_circuits
# distance (m)
m5_total_dist <- nrow(clean_d_mill5)*0.848
m5_total_dist

# calculating average speed
# total distance flown 
total_dist <- sum(clean_d_mill5$Distance)
# total time flown 
total_time <- sum(clean_d_mill5$Interval)
# average speed 
mean_speed5 <- total_dist/total_time

# calculating distance for each leg 
leg1_m5 <- filter(clean_d_mill5, clean_d_mill5$Leg == "leg 1")
leg1_distm5 <- sum(leg1_m5$Distance)

leg2_m5 <- filter(clean_d_mill5, clean_d_mill5$Leg == "leg 2")
leg2_distm5 <- sum(leg2_m5$Distance)

leg3_m5 <- filter(clean_d_mill5, clean_d_mill5$Leg == "leg 3")
leg3_distm5 <- sum(leg3_m5$Distance)

# calculate total duration of flight 
flight_time_m5 <-sum(clean_d_mill5$Interval)

# calculate duration of each leg 
flighttime_m5leg1 <- sum(leg1_m5$Interval)
flighttime_m5leg2 <- sum(leg2_m5$Interval)
flighttime_m5leg3 <- sum(leg3_m5$Interval)


##### MILL 6 #####

Distance <- c(rep(0.848, times = nrow(clean_d_mill6)))
clean_d_mill6 <- cbind(clean_d_mill6, Distance)
clean_d_mill6$speed <- (0.848/clean_d_mill6$Interval)

# calculating average speed
# total distance flown 
total_dist <- sum(clean_d_mill6$Distance)
# total time flown 
total_time <- sum(clean_d_mill6$Interval)
# average speed 
mean_speed6 <- total_dist/total_time

#### calculate total circuits and distance flown (metres) ####
# circuits
m6_total_circuits <- nrow(clean_d_mill6)
m6_total_circuits
# distance (m)
m6_total_dist <- nrow(clean_d_mill6)*0.848
m6_total_dist

# calculating distance for each leg 
leg1_m6 <- filter(clean_d_mill6, clean_d_mill6$Leg == "leg 1")
leg1_distm6 <- sum(leg1_m6$Distance)

leg2_m6 <- filter(clean_d_mill6, clean_d_mill6$Leg == "leg 2")
leg2_distm6 <- sum(leg2_m6$Distance)

leg3_m6 <- filter(clean_d_mill6, clean_d_mill6$Leg == "leg 3")
leg3_distm6 <- sum(leg3_m6$Distance)

# calculate total duration of flight 
flight_time_m6 <-sum(clean_d_mill6$Interval)

# calculate duration of each leg 
flighttime_m6leg1 <- sum(leg1_m6$Interval)
flighttime_m6leg2 <- sum(leg2_m6$Interval)
flighttime_m6leg3 <- sum(leg3_m6$Interval)

####### MAKE NEW DATAFRAME WITH THE OUTPUTS OF MILLS 1-6 #######
mill <- c("Mill 1", "Mill 2", "Mill 3", "Mill 4", "Mill 5", "Mill 6")
total_distance <- c(m1_total_dist, m2_total_dist, m3_total_dist, m4_total_dist, m5_total_dist, m6_total_dist)
circuits <- c(m1_total_circuits, m2_total_circuits, m3_total_circuits, m4_total_circuits, m5_total_circuits, m6_total_circuits)
mean_speed <- c(mean_speed1, mean_speed2, mean_speed3, mean_speed4, mean_speed5, mean_speed6)
leg1_distance <- c(leg1_distm1, leg1_distm2, leg1_distm3, leg1_distm4, leg1_distm5, leg1_distm6)
leg2_distance <- c(leg2_distm1, leg2_distm2, leg2_distm3, leg2_distm4, leg2_distm5, leg2_distm6)
leg3_distance <- c(leg3_distm1, leg3_distm2, leg3_distm3, leg3_distm4, leg3_distm5, leg3_distm6)
total_flighttime <- c(flight_time_m1, flight_time_m2, flight_time_m3, flight_time_m4, flight_time_m5, flight_time_m6)
leg1_flighttime <- c(flighttime_m1leg1, flighttime_m2leg1, flighttime_m3leg1, flighttime_m4leg1, flighttime_m5leg1, flighttime_m6leg1)
leg2_flighttime <- c(flighttime_m1leg2, flighttime_m2leg2, flighttime_m3leg2, flighttime_m4leg2, flighttime_m5leg2, flighttime_m6leg2)
leg3_flighttime <- c(flighttime_m1leg3, flighttime_m2leg3, flighttime_m3leg3, flighttime_m4leg3, flighttime_m5leg3, flighttime_m6leg3)
output <- cbind(mill, circuits, leg1_distance, leg2_distance, leg3_distance, total_distance,leg1_flighttime, leg2_flighttime, leg3_flighttime, total_flighttime,mean_speed)

# make dataframe and numeric 
output <- data.frame(output)
output$mill <- as.character(output$mill)
output$total_distance <- as.character(output$total_distance)
output$total_distance <- as.numeric(output$total_distance)
output$circuits <- as.character(output$circuits)
output$circuits <- as.numeric(output$circuits)
output$mean_speed <- as.character(output$mean_speed)
output$mean_speed <- as.numeric(output$mean_speed)
output$leg1_distance <- as.character(output$leg1_distance)
output$leg1_distance <- as.numeric(output$leg1_distance)
output$leg2_distance <- as.character(output$leg2_distance)
output$leg2_distance <- as.numeric(output$leg2_distance)
output$leg3_distance <- as.character(output$leg3_distance)
output$leg3_distance <- as.numeric(output$leg3_distance)
output$total_flighttime <- as.character(output$total_flighttime)
output$total_flighttime <- as.numeric(output$total_flighttime)
output$leg1_flighttime <- as.character(output$leg1_flighttime)
output$leg1_flighttime <- as.numeric(output$leg1_flighttime)
output$leg2_flighttime <- as.character(output$leg2_flighttime)
output$leg2_flighttime <- as.numeric(output$leg2_flighttime)
output$leg3_flighttime <- as.character(output$leg3_flighttime)
output$leg3_flighttime <- as.numeric(output$leg3_flighttime)



# replace NAs with 0 
output$total_distance[is.na(output$total_distance)] <- 0
output$mean_speed[is.na(output$mean_speed)] <- 0
output$leg1_distance[is.na(output$leg1_distance)] <- 0
output$leg2_distance[is.na(output$leg2_distance)] <- 0
output$leg3_distance[is.na(output$leg3_distance)] <- 0
output$total_flighttime[is.na(output$total_flighttime)] <- 0
output$leg1_flighttime[is.na(output$leg1_flighttime)] <- 0
output$leg2_flighttime[is.na(output$leg2_flighttime)] <- 0
output$leg3_flighttime[is.na(output$leg3_flighttime)] <- 0

# write csv of new dataframe
filename <- paste(flight_date, "_output", ".csv")
write.csv(output, file = filename)

mill1name <- paste(flight_date, "mill1", ".csv")
write.csv(clean_d_mill1, file = mill1name)

mill2name <- paste(flight_date, "mill2", ".csv")
write.csv(clean_d_mill2, file = mill2name)

mill3name <- paste(flight_date, "mill3", ".csv")
write.csv(clean_d_mill3, file = mill3name)

mill4name <- paste(flight_date, "mill4", ".csv")
write.csv(clean_d_mill4, file = mill4name)

mill5name <- paste(flight_date, "mill5", ".csv")
write.csv(clean_d_mill5, file = mill5name)

mill6name <- paste(flight_date, "mill6", ".csv")
write.csv(clean_d_mill6, file = mill6name)

######### written by C.SARGENT 17/05/2019  (last updated:07/08/2019) ##########

######################## END ############################


